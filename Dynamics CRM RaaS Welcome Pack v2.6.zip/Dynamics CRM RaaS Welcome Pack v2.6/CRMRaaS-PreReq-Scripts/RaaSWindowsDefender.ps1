Get-WinEvent -FilterHashtable @{ProviderName="Microsoft-Windows-Windows Defender"; id=1116} |fl;
Get-WinEvent -FilterHashtable @{ProviderName="Microsoft-Windows-Windows Defender"; id=1117} |fl;